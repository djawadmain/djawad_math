# djawad_math
math calculating module

for running write this command
```bash
python math_module/main.py <math_function> <args>
```

for example
```bash
python math_module/main.py fibonacci 10
>>> 55
```
