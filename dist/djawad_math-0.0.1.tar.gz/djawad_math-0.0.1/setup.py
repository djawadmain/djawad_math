from setuptools import setup

setup(
    name='djawad_math',
    version='0.0.1',
    install_requires=[
        'importlib-metadata; python_version == "3.8"'
    ],
    license='MIT'
)
