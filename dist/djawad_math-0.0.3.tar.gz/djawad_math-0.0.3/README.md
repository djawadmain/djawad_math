# djawad_math
math calculating module

for running write this command
```bash
python -m math_module <math_function> <args>
```

for example
```bash
python -m math_module fibonacci 10
>>> 55
```
