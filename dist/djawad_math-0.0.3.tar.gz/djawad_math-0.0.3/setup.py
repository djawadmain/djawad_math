from setuptools import setup

setup(
    name='djawad_math',
    version='0.0.3',
    license='MIT'
)
